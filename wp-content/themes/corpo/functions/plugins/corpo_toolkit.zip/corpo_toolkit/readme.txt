=== Corpo Toolkit Plugin ===
Contributors: alex27
Author: alex27 (Aleksandra Laczek)
Author URI: http://webtuts.pl/
Requires at least: 3.3
Tested up to: 3.5.2
License: GPLv2 or later

Custom Post Types and shortcode functionality for Corpo Theme.


== Installation ==

After theme (Corpo or Corpo Pro) installation you’ll see notice asking you to install Corpo Toolkit plugin. 
This plugin is bundled with the theme, so you don’t need to download anything. After you’ve installed the plugin, be sure to activate!
If you dismissed the notice before installing Corpo Toolkit plugin, you can always access install page from Appereance->Install plugins.


== Changelog ==

= 1.4 =
* Added links to slides

= 1.3 =
* Added option to overwrite CPT template in theme
* Added option to create custom Portfolio page title

= 1.2 =
* Changed slug for Services Taxonomy to project-services
* Added flush_rewrite_rules() on plugin activation
* Added readme.txt
    
= 1.1 =
* [Bugfix] Fixed projects display on home page    
    
= 1.0 =
* Initial release